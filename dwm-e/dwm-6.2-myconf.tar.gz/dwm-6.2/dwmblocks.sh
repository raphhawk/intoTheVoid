#! /bin/bash

bat(){
read -r cap < /sys/class/power_supply/BAT0/capacity

fullpx=$((cap/6))
emptpx=$((20-fullpx))

bat="^r0,7,2,4^^r2,4,22,10^^c#000000^^r3,5,20,8^^c#ffffff^^r10,5,13,8^^d^^f24^"

status=$(sed "s/Not charging/ /; s/Charging/ /; s/Discharging/ /; s/Unknown/ /; s/Full/ /; s/[A-Za-z]*//" /sys/class/power_supply/BAT0/status)

echo " $status$cap%"
}

vol(){
if vol=$(pamixer --get-volume --get-mute) ; then
    printf "🔇%3s%%\n" "${vol##* }"
elif [ "${vol##* }" -eq 0 ]; then
    printf "🔇%3s%%\n" "${vol##* }"
elif [ "${vol##* }" -gt 66 ]; then
    printf "🔊%3s%%\n" "${vol##* }"
elif [ "${vol##* }" -gt 33 ]; then
    printf "🔉%3s%%\n" "${vol##* }"
else
    printf "🔈%3s%%\n" "${vol##* }"
fi
}

bri(){
a="$(brightnessctl g)"
echo "" $((a/12))% 
}

net(){
state="$(sed "s/up//; s/down//; s/dormant/🔃/" /sys/class/net/wlp5s0/operstate)"
state="${state}$(sed "s/up//; s/down//" /sys/class/net/enp3s0/operstate)"

if [ -z "$state" ]; then
    printf "\n"
else
    printf "%s\n" "$state"
fi
}

dat(){
hourmin=$(date -d "+15min" '+%I;%M')

if [ "${hourmin#*;}" -gt 30 ]; then
    hour="${hourmin%;*}30"
else
    hour="${hourmin%;*}00"
fi

case "$hour" in
    "0000") icon="🕛" ;;
    "0100") icon="🕐" ;;
    "0200") icon="🕑" ;;
    "0300") icon="🕒" ;;
    "0400") icon="🕓" ;;
    "0500") icon="🕔" ;;
    "0600") icon="🕕" ;;
    "0700") icon="🕖" ;;
    "0800") icon="🕗" ;;
    "0900") icon="🕘" ;;
    "1000") icon="🕙" ;;
    "1100") icon="🕚" ;;
    "1200") icon="🕛" ;;
    "0030") icon="🕧" ;;
    "0130") icon="🕜" ;;
    "0230") icon="🕝" ;;
    "0330") icon="🕞" ;;
    "0430") icon="🕟" ;;
    "0530") icon="🕠" ;;
    "0630") icon="🕡" ;;
    "0730") icon="🕢" ;;
    "0830") icon="🕣" ;;
    "0930") icon="🕤" ;;
    "1030") icon="🕥" ;;
    "1130") icon="🕦" ;;
    "1230") icon="🕧" ;;
    *) icon="Err!";;
esac

date "+%d-%m-%Y clk %R" | sed "s/clk/$icon/"
}



while true; do
	#xsetroot -name "$(bat)|$(vol)|$(bri)|$(net)|$(date)"
	xsetroot -name "$(bat)|$(net)|$(bri)|$(vol)|$(dat)"
	sleep 1m
done
